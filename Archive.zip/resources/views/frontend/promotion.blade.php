@extends('user_layout.app')
@include('user_layout.nav')
@section('content')
<div class="row">
 <div class="col-lg-4 col-md-4 offset-lg-4 offset-md-4 mt-5  text-white" style="background-color: #b6c5d8;padding-bottom: 200px;padding-top: 20px;">
  <div class="d-flex justify-content-around align-items-center px-3 py-1 my-2 rounded " style="background-color: #336876;">
   <a href="{{ url('/promoDetail') }}" style="text-decoration: none;" class="d-flex justify-content-around align-items-center text-white">
    <img src="{{ asset('user_app/assets/images/promotion/promo_1.png') }}" style="width: 50px;height: 50px;border-radius: 50%;" alt="">
    <p class="mx-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
     industry's standard dummy text ever since the 1500s</p>
    <span>
     <a class="material-icons text-white" style="text-decoration: none;" href="{{ url('/promoDetail') }}">chevron_right</a>
    </span>
   </a>
  </div>

  <div class="d-flex justify-content-around align-items-center px-3 py-1 my-2 rounded " style="background-color: #336876;">
   <a href="{{ url('/promoDetail') }}" style="text-decoration: none;" class="d-flex justify-content-around align-items-center text-white">
    <img src="{{ asset('user_app/assets/images/promotion/promo_1.png') }}" style="width: 50px;height: 50px;border-radius: 50%;" alt="">
    <p class="mx-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
     industry's standard dummy text ever since the 1500s</p>
    <span>
     <a class="material-icons text-white" style="text-decoration: none;" href="{{ url('/promoDetail') }}">chevron_right</a>
    </span>
   </a>
  </div>

  <div class="d-flex justify-content-around align-items-center px-3 py-1 my-2 rounded " style="background-color: #336876;">
   <a href="{{ url('/promoDetail') }}" style="text-decoration: none;" class="d-flex justify-content-around align-items-center text-white">
    <img src="{{ asset('user_app/assets/images/promotion/promo_1.png') }}" style="width: 50px;height: 50px;border-radius: 50%;" alt="">
    <p class="mx-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
     industry's standard dummy text ever since the 1500s</p>
    <span>
     <a class="material-icons text-white" style="text-decoration: none;" href="{{ url('/promoDetail') }}">chevron_right</a>
    </span>
   </a>
  </div>

  <div class="d-flex justify-content-around align-items-center px-3 py-1 my-2 rounded " style="background-color: #336876;">
   <a href="{{ url('/promoDetail') }}" style="text-decoration: none;" class="d-flex justify-content-around align-items-center text-white">
    <img src="{{ asset('user_app/assets/images/promotion/promo_1.png') }}" style="width: 50px;height: 50px;border-radius: 50%;" alt="">
    <p class="mx-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
     industry's standard dummy text ever since the 1500s</p>
    <span>
     <a class="material-icons text-white" style="text-decoration: none;" href="{{ url('/promoDetail') }}">chevron_right</a>
    </span>
   </a>
  </div>

  <div class="d-flex justify-content-around align-items-center px-3 py-1 my-2 rounded " style="background-color: #336876;">
   <a href="{{ url('/promoDetail') }}" style="text-decoration: none;" class="d-flex justify-content-around align-items-center text-white">
    <img src="{{ asset('user_app/assets/images/promotion/promo_1.png') }}" style="width: 50px;height: 50px;border-radius: 50%;" alt="">
    <p class="mx-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
     industry's standard dummy text ever since the 1500s</p>
    <span>
     <a class="material-icons text-white" style="text-decoration: none;" href="{{ url('/promoDetail') }}">chevron_right</a>
    </span>
   </a>
  </div>

  <div class="d-flex justify-content-around align-items-center px-3 py-1 my-2 rounded " style="background-color: #336876;">
   <a href="{{ url('/promoDetail') }}" style="text-decoration: none;" class="d-flex justify-content-around align-items-center text-white">
    <img src="{{ asset('user_app/assets/images/promotion/promo_1.png') }}" style="width: 50px;height: 50px;border-radius: 50%;" alt="">
    <p class="mx-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
     industry's standard dummy text ever since the 1500s</p>
    <span>
     <a class="material-icons text-white" style="text-decoration: none;" href="{{ url('/promoDetail') }}">chevron_right</a>
    </span>
   </a>
  </div>

 </div>
</div>

@include('user_layout.footer')
@endsection