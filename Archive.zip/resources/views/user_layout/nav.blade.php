<div class="container-fluid fixed-top">
 <div class="row">
  <div class="col-lg-4 col-md-6 offset-lg-4 offset-md-3 navs">
   <div class="px-3 py-3">
    <div class="d-flex justify-content-between">
        <span>
            <a class="material-icons text-white" href="{{ url()->previous() }}">arrow_back</a>
        </span>
        <h5 class="mx-auto mt-1">
            <a href="{{ url('/') }}" class="text-white">Thailotto123</a>
        </h5>
     <span class="mt-1">
      <a class="material-icons text-white" href="{{ url('/') }}">refresh</a>
     </span>
    </div>
   </div>
  </div>
 </div>
</div>
