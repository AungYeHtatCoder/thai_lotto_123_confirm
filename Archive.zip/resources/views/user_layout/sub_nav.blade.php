<div class="row">
 <div class="col-lg-4 col-md-4 offset-lg-4 offset-md-4 navs fixed-top">
  <div class="px-3 py-3">
   <div class="d-flex justify-content-between">
    <span>
     <a class="material-icons text-white" href="{{ url()->previous() }}">arrow_back</a>
    </span>
    <h5 class="mx-auto">
     <a href="{{ url('/') }}" class="text-white">Thai Lotto 123</a>
    </h5>
    <span>
     <a class="material-icons text-white" href="{{ url('/') }}">refresh</a>
    </span>
   </div>
  </div>
 </div>
</div>
